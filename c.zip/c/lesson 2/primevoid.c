#include <stdio.h>

void goahead(int a); // Function prototype

int main(int argc, char const *argv[])
{
    int a; 
    printf ("Enter an integer: ");
    scanf ("%d", &a);
    
    if (a == 1 || a == 0)
    {
        printf ("Please enter an integer other than 1 and 0\n");
    }
    else
    {
        goahead(a); // Pass the value of 'a' to the function
    }
    
    return 0;
}

void goahead(int a)
{
    int i, count = 0;
    
    for (i = 1; i <= a; i++)
    {
        if (a % i == 0)
        {
            count = count + 1;
        }
    }
    
    if (count == 2)
    {
        printf ("%d is a prime number\n", a);
    }
    else
    {
        printf ("%d is not a prime number\n", a);
    }
}
