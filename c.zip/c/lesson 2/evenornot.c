#include <stdio.h>
int main(int argc, char const *argv[])
{
    int a, e;
    printf ("Enter a Number: ");
     scanf ("%d", &a);
    e = a % 5;
    if (e == 0)
    {
        printf ("%d is a Even Number", a);
    }
    else
    {
        printf ("%d is not Even Number", a);
    }
    
    return 0;
}
