#include <stdio.h>
int main(int argc, char const *argv[])
{
    int n, c = 0, i;
    printf ("Enter a Number: ");
     scanf ("%d", &n);
    for ( i = 1; i <= n; i++)
    {
        if (n % i == 0)
        {
            c++;
        }
        
    }
    if (c == 2)
    {
        printf ("%d is prime Number", n);
    }
    else
    {
        printf ("%d is composite Number", n);
    }
    
    
    return 0;
}
