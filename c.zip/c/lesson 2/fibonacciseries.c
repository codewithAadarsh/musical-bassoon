#include <stdio.h>

int main() {
    int a, b, c;
    int n;

    printf("Enter any two numbers: ");
     scanf("%d %d", &a, &b);

    printf("Enter up to what number do you want to print Fibonacci sequence: ");
     scanf("%d", &n);

    for (int i = 0; a <= n; i++) {
        printf("%d\t", a);

        c = a + b;
        a = b;
        b = c;

        if (a > n) {
            printf("\n");
            i = -1;  //     This is for to reset i to start new line
        }
    }

    return 0;
}
