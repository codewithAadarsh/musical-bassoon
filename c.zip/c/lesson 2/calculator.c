#include <stdio.h>
int main(int argc, char const *argv[])
{
    int e, a, b, p;
    printf ("\t 1- Add\n");
    printf ("\t 2- Sub\n");
    printf ("\t 3- Div\n");
    printf ("\t 4-Mul\n");
    printf ("-----------------------\n");
    printf ("Choose 1 for Add, 2 for Sub, 3 for Div, 4 for Mul: ");
     scanf ("%d", &e);
    printf ("Enter two Integer: ");
     scanf ("%d %d", &a, &b);
    switch (e)
    {
    case 1:
        p = a + b;
        printf ("Addition of %s and %d is %d", a, b, p);
        break;
    case 2:
       if (a > b)
       {
        p = a - b;
        printf ("Subtraction of %d and %d is %d", a, b, p);
       }
       else if (a < b)
       {
        p = b - a;
        printf ("Subtraction of %d and %d is %d", a, b, p);
       }
       else
       {
        p = a - b;
        printf ("Subtraction of %d and %d is %d", a, b, p);
       }
       break;
       case 3:
       p = a / b;
       printf ("Division od %d and %d is %d", a, b, p);
       break;
       case 4:
       p = a * b;
       printf ("Multiplication of d and %d is %d", a, b, p);
       break;
    default:
    printf ("Please, Enter valid option 1 to 4");
        break;
    }

        
    return 0;
}
