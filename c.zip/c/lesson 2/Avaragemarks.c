
#include <stdio.h>

void goahead(int hold);

int main(int argc, char const *argv[])
{
    int c, w, a, e, ma;
    double total, hold;
    printf ("Avarage \t\t\t Grade\n");
    printf ("Greater than 90 \t\t A+\n");
    printf ("From 90 to  80 \t\t\t A\n");
    printf ("From 79 to 60 \t\t\t B+\n");
    printf ("From 59 to 40 \t\t\t B\n");
    printf ("From 39 to 30 \t\t\t C+\n");
    printf ("From 29 to 20  \t\t\t C\n");
    printf ("Below 20 \t\t\t Fail\n");

    printf ("Enter a marks of C Programing: ");
     scanf ("%d", &c);
    printf ("Enter a marks of Website Design: ");
     scanf ("%d", &w);
    printf ("Enter a marks of Fundamental of Computer and Application: ");
     scanf ("%d", &a);
    printf ("Enter a marks of Fundamental of Electro System: ");
     scanf ("%d", &e);
    printf ("Enter a marks of Math: ");
     scanf ("%d", &ma);

    total = (c + w + a + e)/ 5.0;
    if (total >= 500)
    {
        printf ("Please, Enter a marks that you got in 100 Marks");
    }
    else
    {
        goahead((int)total);
    }
    
    return 0;
}

void goahead (int hold)
{
 if (hold >= 90)
 {
    printf ("You graded A+ in exam by scoring %d", hold);
 }
 else if (hold >= 80)
 {
    printf ("You graded A in exam by scoring %d", hold);
 }
 else if (hold >= 60)
 {
    printf ("You graded B+ in exam by scoring %d", hold);
 }
 else if (hold >= 40)
 {
    printf ("You graded B in exam by scoring %d", hold);
 }
 else if (hold >= 30)
 {
    printf ("You graded C+ in exam by scoring %d", hold);
 }
 else if (hold >= 20)
 {
    printf ("You graded C in exam by scoring %d", hold);
 }
 else
 {
    printf ("You graded Fail in exam by scoring %d", hold);
 }
 
 
}