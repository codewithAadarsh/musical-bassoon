#include <stdio.h>

int main()  {
    int choice;

    printf("Choose an option:\n");
    printf("1. Convert Decimal to Binary\n");
    printf("2. Convert Binary to Decimal\n");
    scanf("%d", &choice);

    switch (choice) {
        case 1:
            decimalToBinary();
            break;
        case 2:
            binaryToDecimal();
            break;
        default:
            printf("Invalid option. Please choose 1 or 2.\n");
            break;
    }

    return 0;
}

void decimalToBinary() {
    int decimal, binary = 0, base = 1;

    printf("Enter a decimal number: ");
    scanf("%d", &decimal);

    if (decimal < 0) {
        printf("Please enter a non-negative decimal number.\n");
        return;
    }

    while (decimal > 0) {
        int remainder = decimal % 2;
        binary = binary + remainder * base;
        decimal = decimal / 2;
        base = base * 10;
    }

    printf("Binary equivalent: %d\n", binary);
}

void binaryToDecimal() {
    long long binary;
    int decimal = 0, base = 1;

    printf("Enter a binary number: ");
    scanf("%lld", &binary);

    while (binary > 0) {
        int digit = binary % 10;
        if (digit != 0 && digit != 1) {
            printf("Invalid binary number. Please enter a valid binary number.\n");
            return;
        }
        decimal = decimal + digit * base;
        binary = binary / 10;
        base = base * 2;
    }

    printf("Decimal equivalent: %d\n", decimal);
}
