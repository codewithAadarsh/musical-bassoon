#include <stdio.h>

void goahead(double hold);

int main()
{
    double c, w, a, e, ma;
    double total;

    printf("Average\t\t\t Grade\n");
    printf("Greater than 90\t\t A+\n");
    printf("From 90 to 80\t\t A\n");
    printf("From 79 to 60\t\t B+\n");
    printf("From 59 to 40\t\t B\n");
    printf("From 39 to 30\t\t C+\n");
    printf("From 29 to 20\t\t C\n");
    printf("Below 20\t\t Fail\n");

    printf("Enter marks for C Programming: ");
    scanf("%lf", &c);
    printf("Enter marks for Website Design: ");
    scanf("%lf", &w);
    printf("Enter marks for Fundamental of Computer and Application: ");
    scanf("%lf", &a);
    printf("Enter marks for Fundamental of Electro System: ");
    scanf("%lf", &e);
    printf("Enter marks for Math: ");
    scanf("%lf", &ma);

    // Validate input marks
    if (c < 0 || c > 100 || w < 0 || w > 100 || a < 0 || a > 100 || e < 0 || e > 100 || ma < 0 || ma > 100)
    {
        printf("Invalid input. Marks should be between 0 and 100.\n");
        return 1; // Exit with an error code
    }

    total = (c + w + a + e + ma) / 5.0;

    if (total > 100)
    {
        printf("Total marks exceed 500. Please enter marks in a 100-point scale.\n");
        return 1; // Exit with an error code
    }
    else
    {
        goahead(total);
    }

    return 0;
}

void goahead(double hold)
{
    printf("You scored %.2lf marks and received the following grade:\n", hold);

    if (hold >= 90)
    {
        printf("A+\n");
    }
    else if (hold >= 80)
    {
        printf("A\n");
    }
    else if (hold >= 60)
    {
        printf("B+\n");
    }
    else if (hold >= 40)
    {
        printf("B\n");
    }
    else if (hold >= 30)
    {
        printf("C+\n");
    }
    else if (hold >= 20)
    {
        printf("C\n");
    }
    else
    {
        printf("Fail\n");
    }
}
