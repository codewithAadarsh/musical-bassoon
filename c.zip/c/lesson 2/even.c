#include <stdio.h>

int main() {
    int n;

    printf("Enter the number up to which you want to print even numbers: ");
    scanf("%d", &n);

    for (int i = 2; i <= n; i += 2) {
        printf("%d ", i);
    }

    printf("\n");

    return 0;
}
