#include <stdio.h>
int main(int argc, char const *argv[])
{
    char a;
    printf ("Enter aChareter:");
     scanf ("%c", &a);
    printf ("%c is our Character", a);

    return 0;
}
