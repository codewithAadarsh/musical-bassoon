#include <stdio.h>

int main(int argc, char const *argv[])
{
    int sales, com;

    printf("Sales Amount \t\t\t Commission\n");
    printf("0-10000 \t\t\t 5 percent\n");
    printf("10001-20000 \t\t\t 10 percent\n");
    printf("20001-50000 \t\t\t 15 percent\n");
    printf("Above 50000 \t\t\t 20 percent\n");
    printf("--------------------------------------------\n");

    printf("Enter Amount of Sales: ");
    if (scanf("%d", &sales) != 1) {
        printf("Invalid input. Please enter a valid integer.\n");
        return 1;
    }

    if (sales < 0) {
        printf("Invalid input. Sales amount cannot be negative.\n");
    } else if (sales <= 10000) {
        com = (5 * sales) / 100;
        printf("You earn %d from %d\n", com, sales);
    } else if (sales <= 20000) {
        com = (10 * sales) / 100;
        printf("You earn %d from %d\n", com, sales);
    } else if (sales <= 50000) {
        com = (15 * sales) / 100;
        printf("You earn %d from %d\n", com, sales);
    } else {
        com = (20 * sales) / 100;
        printf("You earn %d from %d\n", com, sales);
    }

    return 0;
}
