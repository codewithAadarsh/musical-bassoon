#include <stdio.h>
int main(int argc, char const *argv[])
{
    char a1[20], a2[20], a3[20], a4[20], a5[20];
    printf("Enter the Name of student\n");
    scanf("%s", &a1);
    printf("Enter the Name of student\n");
    scanf("%s", &a2);
    printf("Enter the Name of student\n");
    scanf("%s", &a3);
    printf("Enter the Name of student\n");
    scanf("%s", &a4);
    printf("Enter the Name of student\n");
    scanf("%s", &a5);
    
    printf("\n1. %s", a1);
    printf("\n2. %s", a2);
    printf("\n3. %s", a3);
    printf("\n4. %s", a4);
    printf("\n5. %s", a5);
    return 0;
}
