#include <stdio.h>
int main(int argc, char const *argv[])
{
    int a, p, r;
    printf("Enter the value of ridius");
    scanf("%d", &r);
    // Calculate Perimeter and Area using formulae
    p = 2 * (3.14) * r;
    a = (3.14) * r * r;
    /* Printing the results */
    printf("\nThe perimeter of the circle is %d\n", p);
    printf("The area of the circle is %d", a);
    
    return 0;
}
