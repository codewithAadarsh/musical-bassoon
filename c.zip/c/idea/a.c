#include <stdio.h>
#include <string.h>
#include <ctype.h>

int isOperand(char x) {
    return isalpha(x);
}

int getPriority(char x) {
    switch(x) {
        case '+':
        case '-':
            return 1;
        case '*':
        case '/':
            return 2;
        case '^':
            return 3;
    }
    return 0;
}

void infixToPostfix(char infix[], char postfix[]) {
    int i, j, k, n, p, open = 0;
    char symb, top;
    char stack[50];

    n = strlen(infix);
    for(i = 0, j = 0; i < n; i++) {
        if(isOperand(infix[i])) {
            postfix[j++] = infix[i];
        } else if(infix[i] == '(') {
            stack[open++] = infix[i];
        } else if(infix[i] == ')') {
            while((symb = stack[--open]) != '(') {
                postfix[j++] = symb;
            }
        } else {
            while((open != 0) && (p <= getPriority(infix[i]))) {
                symb = stack[--open];
                postfix[j++] = symb;
                p = getPriority(symb);
            }
            stack[open++] = infix[i];
        }
    }

    while(open != 0) {
        symb = stack[--open];
        postfix[j++] = symb;
    }

    postfix[j] = '\0';
}

int evalPostfix(char postfix[]) {
    int i, val, num1, num2;
    char symb;
    for(i = 0; i < strlen(postfix); i++) {
        symb = postfix[i];
        if(isOperand(symb)) {
            push(symb - '0');
        } else {
            num2 = pop();
            num1 = pop();
            switch(symb) {
                case '+': push(num1 + num2); break;
                case '-': push(num1 - num2); break;
                case '*': push(num1 * num2); break;
                case '/': push(num1 / num2); break;
            }
        }
    }
    return pop();
}

int main() {
    char infix[50], postfix[50];
    printf("Enter infix expression: ");
    fgets(infix, sizeof(infix), stdin);

    infixToPostfix(infix, postfix);
    printf("Postfix expression: %s\n", postfix);
    printf("Result: %d\n", evalPostfix(postfix));

    return 0;
}