// #include <stdio.h>
// void div();
// int main(int argc, char const *argv[])
// {
//     int x;
//     x = div();
//     printf("The value of X is %d\n",x);
//     return 0;
// }
// void div() {
//     int a, b, dav;
//     printf("Enter the numerator: ");
//     scanf("%d", &a);
//     printf("Enter the denominator: ");
//     scanf("%d", &b);
//     dav = a / b;
//     return dav;
// }
#include <stdio.h>

void div(int *x);

int main(int argc, char const *argv[])
{
    int x;
    div(&x);
    printf("The division is %d\n", x);
    return 0;
}

void div(int *x) {
    int a, b, dav;
    printf("Enter the numerator: ");
    scanf("%d", &a);
    printf("Enter the denominator: ");
    scanf("%d", &b);
    dav = a / b;
    *x = dav;
}