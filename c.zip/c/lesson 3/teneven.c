// #include <stdio.h>
// void even();
// int main(int argc, char const *argv[])
// {
//     int a;
//     printf("Enter an integer: ");
//     scanf("%d", &a);
//     even(a);
//     return 0;
// }
// void (int a) {
//     int i;
//     for  (i = 0; i < 10; i++)
//     {
//         printf ("%d /t", a);
//         a = a + 2;
//     }
    
// }
#include <stdio.h>

void even(int a);

int main(int argc, char const *argv[])
{
    int a;
    printf("Enter an integer: ");
    scanf("%d", &a);
    even(a);
    return 0;
}

void even(int a) {
    int i;
    for (i = 0; i < 10; i++)
    {
        printf ("%d \t", a);
        a = a + 2;
    }
}