#include <stdio.h>
int mul(int, int);
int main(int argc, char const *argv[])
{
    int a, b, X;
    printf("Enter two numbers: ");
    scanf("%d %d", &a, &b);
   X = mul (a,b);
   printf("\nThe product of %d and %d is : %d\n", a, b,X);
    return 0;
}
int mul (int a, int b) {
    int mul;
    mul= a * b;
    return mul;
}