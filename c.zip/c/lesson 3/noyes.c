#include <stdio.h>
void add(int,  int);
int main() {
    int a, b;
    printf("Enter two numbers: ");
    scanf("%d %d", &a, &b);
    add (a, b);
    return 0;
 }
 void add(a, b) {
    int c = a + b;
    printf("\nThe sum of %d and %d is :%d\n", a, b, c);
    
 }