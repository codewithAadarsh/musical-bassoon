#include <stdio.h>
void sub();
int main(int argc, char const *argv[])
{
    sub();
    return 0;
}
void sub() {
    int a,b, subtraction;
    printf("Enter the first number: ");
    scanf("%d", &a);
    printf("\nEnter the second number: ");
    scanf("%d",&b);
    subtraction = a - b;
    printf("\nThe result of subtraction is %d.",subtraction);
}