#include <stdio.h>
int Addition ();
int main(int argc, char const *argv[])
{
    int a, b, x;
    printf ("Enter any two number: ");
    scanf ("%d %d", &a, &b);
    x = Addition(a, b);
    printf ("The sum is %d", x);
    return 0;
}

int Addition (int a, int b)
{
    int p;
    p = a + b;
    
    return p;
}
 