console.log("Hello  world1")

let a = document.getElementsByClassName("box")
console.log(a);

a[1].style.background = "royalblue"

B = Math.random(0,256) * 10;
console.log(B)
