let arr = [1, 2, 5, 7, 4, 8, 10]
//   INDEX 0, 1, 2, 3, 4, 5, 6

console.log (arr, typeof arr)
console.log (arr.length)

// arr[0] = 7
// console.log (arr[0])

console.log (arr[0])
console.log (arr[1])
console.log (arr[2])
console.log (arr[3])
console.log (arr[4])
console.log (arr[5])

console.log(arr.toString())
console.log(arr.join( " and "))

let loveArray = ["Adarsh", "Prashu"];
console.log(loveArray.join(" Loves "));

a = [1, 2, 3, 4, 5, 6];
console.log(a);
console.log(a.pop());
console.log(a);

console.log(a.push(6))
console.log(a)
console.log(a.push("Adarsh"))
console.log(a)

console.log(a.shift(1));
console.log(a);
console.log(a.unshift("Hacker"));
console.log(a.unshift(1));
console.log(a);

delete a[0]
console.log(a)
console.log(a.length)

xarr = [1, 2, 3, 4]
yarr = [5, 6, 7, 8]
zarr = [9, 10, 11, 12]
console.log(xarr.concat(yarr,zarr));
console.log([...xarr, ...yarr, ...zarr]);

console.log(a.sort());

let number = [1, 2, 3, 4, 5];
console.log(number.splice(1, 3));
console.log(number);
console.log(number.splice(1, 5, 111, 666));
console.log(number);

const num = [1, 2, 3, 4, 5]
console.log(num.slice(0, 3));
console.log(num.slice(1)); 

const ab = [1, 2, 3, 4, 5, 6, 7, 8, 9];
console.log(ab.reverse());

