obj = {
    nam: "Adarsh",
    middle: "Chaudhary",
    title: "",
}
var a = obj;
var b = (console.log(a.nam?.middle?.title))

let ab = b ?? "CodewithAdarsh"
console.log(ab)