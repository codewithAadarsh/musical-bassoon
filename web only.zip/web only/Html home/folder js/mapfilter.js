let arr = [1, 2, 3, 4, 5, 6]
// let newarr = []

// for (let index = 0; index < arr.length; index++) {
//     const element = arr[index];
//     newarr.push(element**2)
// }

let newarr = arr.map((e, index, arr)=>{
    return e**2
})
console.log(newarr)

const greaterthan2 = (e)=>{
    if(e>2){
        return true
    }
    return false
}
console.log(newarr.filter(greaterthan2))
console.log(arr.filter(greaterthan2))

let arr2 = [1, 2, 3, 4, 5, 6 ,7, 8]
const abc = (a, b)=>{
    return a + b;
}
console.log(arr2.reduce(abc))


console.log(Array.from("ADARSH"))

