console.log(newarr)

const greaterthan2 = (e)=>{
    if(e>2){
        return true
    }
    return false
}