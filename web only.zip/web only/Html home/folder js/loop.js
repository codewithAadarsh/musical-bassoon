console.log("I am learing loops in Javascript");
//for loop is used to iterate over a given range of numbers
/*Syntax:
for (initialization; condition; increment/decrement) {
    // code block to be executed
    }
    */
    let a = 0;
    for (let i = 0; i  < 100; i++) {
        console.log(a + 1);
        a = a + 1;
    }

let obj = {
    name : "Adarsh",
    role : "C.E.O",
    company : "CodewithAdarsh auto Mobile PVT.LTM",

}


// for (const key in object) {
//     if (Object.hasOwnProperty.call(object, key)) {
//         const element = object[key];
        
//     }
// }
for (const key in obj){
    console.log(key)
} 


// for (const iterator of object) {
    
// }      
for (const c of "Adarsh chaudhary") {
    console.log(c);
}


// while (condition) {
    
// }
let i = 1;
while (i < 8) {
    console.log(i)
    i++;
}


// do {
    
// } while (condition);
g = 1;
do {
    console.log(g)
    g++;
} while (i < 10);
