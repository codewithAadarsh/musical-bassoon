function nice(name) {
    console.log("I am  learning Function in Javascript " + name);
    console.log("I am felling good " + name);
    console.log("I am the best Programmer " + name);
    console.log("I am having best time with Javascript " + name);
}
nice("Adarsh Chaudhary")
nice("Chaudhary Adarsh")

// console.log("I am  learning Function in Javascript Adarsh chaudhary");
// console.log("I am felling good Adarsh chaudhary");
// console.log("I am the best Programmer Adarsh chaudhary");
// console.log("I am having best time with Javascript Adarsh chaudhary");

function sum(a, b, c =  0) {
    console.log(a + b + c);
}
result1 = sum(10, 20);
result2 = sum(11, 40);
result3 = sum(56, 20);

function sum(a, b) {
    return (a + b);
}
console.log("The sum of these number is:", result1);
console.log("The sum of these number is:", result2);
console.log("The sum of these number is:", result3);

const func1 = (x)=>{
    console.log("I am arrow function", x);
}
func1(34);
func1(47);
func1(56);
func1(88);