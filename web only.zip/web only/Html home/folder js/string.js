console.log("I am learing string value in Javescript");


let a = "Adarsh";
console.log(a[0]);
console.log(a[1]);
console.log(a[2]);
console.log(a[3]);
console.log(a[4]);
console.log(a[5]);
console.log(a[6]);// there is no letter is so, it is undefined
console.log(a.length);
console.log(a);

let my_name = "Adarsh chaudhary";
let friend = "Anish";
console.log(`My name is ${my_name} and I have a friend named ${friend}`);
console.log("My Name is " + my_name + "and MY friend name is " + friend);

let b = "prashu"
console.log(b.toUpperCase());
console.log(b.toLowerCase());
console.log(b.split());
console.log(b.length);
console.log(b.slice(0, 3));
console.log(b.slice(3));
console.log(b.replace("pra", "shu"));
console.log(b.replace("shu", "pra"));

console.log((a).concat(b));
console.log((a).concat(b, "Chaudhary", "Bohorha"));