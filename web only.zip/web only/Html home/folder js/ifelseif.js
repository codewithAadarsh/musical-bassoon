let age = 5;
let waitthreeyear = 3;

age = waitthreeyear;
console.log(age);
age += waitthreeyear;
console.log(age);
age -= waitthreeyear;
console.log(age);
age *= waitthreeyear;
console.log(age);
age /= waitthreeyear;
console.log(age);
age %= waitthreeyear;
console.log(age);
age ** waitthreeyear;
console.log(age);

let nun1 = 3;
let num2 = 5;
console.log(nun1 + num2);
console.log(nun1 - num2);
console.log(nun1 * num2);
console.log(nun1 / num2);
console.log(nun1 + num2);
console.log(nun1 ** num2);
console.log(nun1 % num2);;

let ages = 15;

if (ages>18) {
    console.log("You cannot drink alcohol.");  
} else {
    console.log("You can drink alcohol.");
}


a = 6;
b= 5;
let c = a > b ? (a - b) : (b - a);
console.log(c);

/*
translate to
if (a>b) {
    let c = a - b;   
} else {
    let c = b - a;
}
*/