console.log("This is Addision program")
let a = 10 
let b =  20
c =  a + b
console.log(a+" + "+b+" = "+ c)
console.log(a+b) 