let n = Number(prompt("Enter your number to find factorial"));
console.log(n)