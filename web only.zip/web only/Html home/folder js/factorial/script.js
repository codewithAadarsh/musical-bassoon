let n = Number(prompt("Enter your number to find factorial"));
console.log(n)


let allValues = [];

for (let i = 1; i <= n; i++) {
    allValues.push(i);
}

console.log("All Values:", allValues);



const factor = (a, b) => {
    return a * b;
}

const result = allValues.reduce(factor)

console.log(allValues.join(" * "))

console.log(result)